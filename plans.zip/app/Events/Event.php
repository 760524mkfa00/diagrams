<?php

namespace Plans\Events;

abstract class Event
{
    //
}
